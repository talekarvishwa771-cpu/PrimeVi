/* ==========================================================
   admin.js — admin dashboard: manage projects table + add project
   ========================================================== */

function switchAdminTab(tab){
  document.querySelectorAll("#page-admin .portal-tabs button").forEach(b => b.classList.toggle("active", b.dataset.tab === tab));
  document.querySelectorAll("#page-admin .tabpane").forEach(p => p.classList.remove("active"));
  document.getElementById("adminTab-" + tab).classList.add("active");
  if(tab === "settings") renderSettingsForm();
}

function renderAdmin(){
  document.getElementById("adminCount").textContent = projects.length + " project" + (projects.length === 1 ? "" : "s");
  const body = document.getElementById("adminTableBody");

  body.innerHTML = projects.map(p => `
    <tr>
      <td>${escapeHtml(p.client)}</td>
      <td>${escapeHtml(p.title)}</td>
      <td><span class="mono" style="font-size:0.78rem; color:var(--text-faint);">${p.type}</span></td>
      <td>
        <div class="progress-inline">
          <input type="number" class="row-text" style="width:60px;" min="0" max="100" value="${p.progress}" id="prog-${p.id}">
          <div class="scrub"><div class="scrub-fill" style="width:${p.progress}%;"></div></div>
        </div>
      </td>
      <td>
        <select class="row-select" id="status-${p.id}">
          ${["Submitted","In Progress","In Review","On Hold","Completed"].map(s => `<option value="${s}" ${s === p.status ? "selected" : ""}>${s}</option>`).join("")}
        </select>
      </td>
      <td><button class="btn btn-sm btn-mint" onclick="saveProject(${p.id})">Save</button></td>
    </tr>
  `).join("");
}

function saveProject(id){
  const p = projects.find(pr => pr.id === id);
  if(!p) return;
  const progVal = Math.max(0, Math.min(100, parseInt(document.getElementById("prog-" + id).value, 10) || 0));
  const statusVal = document.getElementById("status-" + id).value;
  p.progress = progVal;
  p.status = statusVal;

  // keep milestone "current" marker roughly in sync with progress
  const doneCount = Math.floor((progVal / 100) * p.milestones.length);
  p.milestones.forEach((m, i) => {
    m.done = i < doneCount;
    m.current = i === doneCount;
  });
  if(statusVal === "Completed"){
    p.progress = 100;
    p.milestones.forEach(m => { m.done = true; m.current = false; });
  }

  renderAdmin();
  showToast(`${p.title} updated — ${p.status}, ${p.progress}%`);
}

function addProject(e){
  e.preventDefault();
  const client = document.getElementById("newClientName").value.trim();
  const title = document.getElementById("newProjTitle").value.trim();
  const type = document.getElementById("newProjType").value;
  const status = document.getElementById("newProjStatus").value;
  const progress = Math.max(0, Math.min(100, parseInt(document.getElementById("newProjProgress").value, 10) || 0));

  projects.push({
    id: nextId++,
    client: client,
    title: title,
    type: type,
    progress: progress,
    status: status,
    milestones: [
      { name: "Kickoff", done: progress > 0, current: progress === 0 },
      { name: type === "Web Development" ? "Design" : "Rough cut", done: progress >= 40, current: progress > 0 && progress < 40 },
      { name: type === "Web Development" ? "Build" : "Color/Sound", done: progress >= 75, current: progress >= 40 && progress < 75 },
      { name: type === "Web Development" ? "Launch" : "Delivery", done: progress >= 100, current: progress >= 75 && progress < 100 }
    ]
  });

  const msg = document.getElementById("newProjMsg");
  msg.className = "form-msg show ok";
  msg.textContent = "Project added to the system.";
  e.target.reset();
  document.getElementById("newProjProgress").value = 0;
  renderAdmin();
  showToast("New project added: " + title);
  setTimeout(() => switchAdminTab('manage'), 700);
}
