/* ==========================================================
   main.js — entry point, boots the app once the DOM is ready
   ========================================================== */

renderNav();
applySiteSettings();
renderFeaturesPublic();
