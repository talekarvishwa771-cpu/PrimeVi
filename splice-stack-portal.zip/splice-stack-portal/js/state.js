/* ==========================================================
   state.js — in-memory application state (no backend / storage;
   resets on page refresh)
   ========================================================== */

let projects = [
  {
    id: 1,
    client: "Fernweg Travel Co.",
    title: "Booking flow rebuild",
    type: "Web Development",
    progress: 70,
    status: "In Progress",
    milestones: [
      { name: "Kickoff", done: true },
      { name: "Design", done: true },
      { name: "Build", done: false, current: true },
      { name: "Launch", done: false }
    ]
  },
  {
    id: 2,
    client: "Fernweg Travel Co.",
    title: "Summer campaign recap video",
    type: "Video Editing",
    progress: 40,
    status: "In Review",
    milestones: [
      { name: "Footage sort", done: true },
      { name: "Rough cut", done: true, current: true },
      { name: "Color/Sound", done: false },
      { name: "Final delivery", done: false }
    ]
  },
  {
    id: 3,
    client: "Northbound Analytics",
    title: "Dashboard v2 rebuild",
    type: "Web Development",
    progress: 100,
    status: "Completed",
    milestones: [
      { name: "Kickoff", done: true },
      { name: "Design", done: true },
      { name: "Build", done: true },
      { name: "Launch", done: true }
    ]
  },
  {
    id: 4,
    client: "Kiln & Co. Ceramics",
    title: "Storefront relaunch",
    type: "Web Development",
    progress: 15,
    status: "On Hold",
    milestones: [
      { name: "Kickoff", done: true, current: true },
      { name: "Design", done: false },
      { name: "Build", done: false },
      { name: "Launch", done: false }
    ]
  },
  {
    id: 5,
    client: "Aperture Films",
    title: "Brand documentary edit",
    type: "Video Editing",
    progress: 55,
    status: "In Progress",
    milestones: [
      { name: "Footage sort", done: true },
      { name: "Rough cut", done: true, current: true },
      { name: "Color/Sound", done: false },
      { name: "Final delivery", done: false }
    ]
  }
];
let nextId = 6;
let selectedRole = "client";
let currentUser = null; // { name, role }

/* Site-wide settings, editable from the admin Settings tab.
   Drives the page <title>, meta tags, nav brand, footer contact
   info, the WhatsApp button number, and the public "Services &
   Add-ons" section. In-memory only — resets on refresh. */
let siteSettings = {
  siteName: "Splice/Stack",
  title: "Splice/Stack — Web Development & Video Editing Studio",
  description: "Splice/Stack is a web development and video editing studio. We build production-ready websites and cut brand films, social content, and documentaries.",
  keywords: "web development, video editing, web design, video production, brand films, agency",
  phone: "+1 555 123 4567",
  email: "hello@splicestack.studio",
  features: [
    { name: "Rush Delivery", description: "48-hour turnaround available for urgent edits and quick-fix builds." },
    { name: "SEO Optimization", description: "On-page SEO structure baked into every web build, not bolted on after." },
    { name: "Motion Graphics Add-on", description: "Custom animated titles and lower-thirds for any video project." },
    { name: "Ongoing Maintenance", description: "Monthly retainer covering updates, backups, and uptime monitoring." }
  ]
};
